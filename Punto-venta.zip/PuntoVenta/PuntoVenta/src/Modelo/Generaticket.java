/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Rectangle;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

/**
 *
 * @author pc
 */
public class Generaticket {

    public void PrintTick(Venta venta, String nombreTick) throws FileNotFoundException, DocumentException {
        // Se crea el documento
        Document documento = new Document();

        FileOutputStream ficheroPdf = new FileOutputStream(nombreTick);

        PdfWriter.getInstance(documento, ficheroPdf).setInitialLeading(30);

// Se abre el documento.
        documento.open();

        try {
            Image foto = Image.getInstance("logo1.png");
            foto.scaleToFit(150, 150);
            foto.setAlignment(Chunk.ALIGN_MIDDLE);
            documento.add(foto);
        } catch (Exception e) {
            e.printStackTrace();
        }

        
        Paragraph paragraph = new Paragraph();
        documento.add(new Paragraph("Consiente a tu mascota como te consientes a ti",
                FontFactory.getFont("arial", // fuente
                        14, // tamaño
                        Font.ITALIC, // estilo
                        BaseColor.DARK_GRAY)));
        paragraph.add(new Phrase(Chunk.NEWLINE));
        documento.add(new Paragraph("" + venta.getFecha()));
        documento.add(new Paragraph("Folio de venta: 0000" + venta.getIdVenta()));
        documento.add(new Paragraph("Atendido por: " + venta.getEmpleado()));
        paragraph.add(new Phrase(Chunk.NEWLINE));
        documento.add(new Paragraph("........................................................................................................................................................ "));
        Producto producto;
        paragraph.add(new Phrase(Chunk.NEWLINE));
        PdfPTable tabla = new PdfPTable(1);
        for (int i = 0; i < venta.getDetallesVenta().size(); i++) {
            tabla.getDefaultCell().setBorderColor(BaseColor.WHITE);
            producto = venta.getDetallesVenta().get(i);
            tabla.addCell(producto.getStock() + "   x   " + producto.getNom_producto() + i + "...........................................................................$" + producto.getSubtotal());
        }
        documento.add(tabla);

        documento.add(new Paragraph("........................................................................................................................................................ "));
        documento.add(new Paragraph("TOTAL:                              $" + venta.getTotal(),
                FontFactory.getFont("arial", // fuente
                        25, // tamaño
                        Font.ITALIC, // estilo
                        BaseColor.DARK_GRAY)));
       paragraph.add(new Phrase(Chunk.NEWLINE));
       documento.add(new Paragraph("CAMBIO:                              $" + venta.getCambio(),
                FontFactory.getFont("arial", // fuente
                        25, // tamaño
                        Font.ITALIC, // estilo
                        BaseColor.DARK_GRAY)));
       paragraph.add(new Phrase(Chunk.NEWLINE));
   documento.add(new Paragraph("                                                                 GRACIAS POR SU COMPRA!",
                FontFactory.getFont("arial", // fuente
                        30, // tamaño
                        Font.ITALIC, // estilo
                        BaseColor.DARK_GRAY)));
        documento.close();

    }
    
    public void abrirarchivo(String nombreTick){

     try {

            File objetofile = new File (nombreTick);
            Desktop.getDesktop().open(objetofile);

     }catch (IOException ex) {

            System.out.println(ex);

     }

}   

}
