/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Controlador.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

/**
 *
 * @author pc
 */
public class ConsultaProveedor {

    Connection con;
    Statement stat;
    ResultSet rs;
    String sql;

 
    public ArrayList <Proveedor> ConsultaProveedor(JComboBox cbxProveedores) {

//Creamos objeto tipo Connection 
        Conexion DB = new Conexion();
        DB.ConexionConfig();
        con = DB.con;
        stat = DB.stm;

        ArrayList <Proveedor> provs=new ArrayList <Proveedor>();
         Proveedor prov;       
//Creamos la Consulta SQL
       
//Establecemos bloque try-catch-finally
        try {

            //Establecemos conexión con la BD 
          
         
             sql= "select * from proveedor ORDER BY nom_proveedor ASC";

            //Ejecutamos la consulta
             java.sql.Statement stm=con.createStatement();
             java.sql.ResultSet res=stm.executeQuery(sql);
            
           
               
            while (res.next()) {

                cbxProveedores.addItem(res.getString("nom_proveedor"));
                prov=new Proveedor(res.getInt(1),res.getString(2),res.getString(3),res.getString(4));
                provs.add(prov);
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, e);

        } 
        
        
        return provs;

    }




   public void ProveedorID(JComboBox cbxProveedores,int ID) {

//Creamos objeto tipo Connection 
        Conexion DB = new Conexion();
        DB.ConexionConfig();
        con = DB.con;
        stat = DB.stm;

        try {

             sql= "select nom_proveedor from producto, folioproveedor, proveedor where producto.id_producto="+ID+" AND proveedor.id_proveedor=folioproveedor.id_proveedor AND producto.id_producto=folioproveedor.id_producto";

            //Ejecutamos la consulta
             java.sql.Statement stm=con.createStatement();
             java.sql.ResultSet res=stm.executeQuery(sql);
            
            while (res.next()) {

                cbxProveedores.addItem(res.getString("nom_proveedor"));
                
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, e);

        } 
        
        
       

    }

}


