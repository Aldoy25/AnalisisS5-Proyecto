package Controlador;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Conexion {
         public  java.sql.Connection con;
         public  Statement stm;
   
     // Create a connection variable and set it to null
   
public void ConexionConfig(){
    try {
        Class.forName("com.mysql.jdbc.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/puntoventa","root","");
        stm=con.createStatement();
        
    }catch(ClassNotFoundException | SQLException e){
         JOptionPane.showMessageDialog(null, "Error Conexion: "+e.getMessage());
    }
}
    
}